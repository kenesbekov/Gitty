import Foundation

enum AppState: Hashable {
    case login
    case loading
    case home
}
