import Foundation

enum APIConstants {
    static let clientID = "Ov23liKBw7Yddbu1ty8g"
    static let clientSecret = "cc04f9881b71ba8d8557c53141583a53c8527180"
    static let redirectURI = "gitty://oauth-callback"
    static let apiBaseURL = "https://api.github.com"
    static let oauthBaseURL = "https://github.com"
}
