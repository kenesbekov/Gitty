import Foundation

struct GetUsersResponse: Decodable {
    let items: [User]
}
