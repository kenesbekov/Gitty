import Foundation

enum RepositorySortKind {
    case stars
    case forks
    case updated
}
