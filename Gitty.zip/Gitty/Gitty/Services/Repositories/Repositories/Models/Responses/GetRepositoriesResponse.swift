import Foundation

struct GetRepositoriesResponse: Codable {
    let items: [Repository]
}
