import Foundation

struct OAuthTokenResponse: Decodable {
    let accessToken: String
}
