import Foundation

protocol RepositoryHistoryCleaner: HistoryCleaner {}
