import Foundation

protocol HistoryCleaner: AnyObject, Sendable {
    func clear()
}
