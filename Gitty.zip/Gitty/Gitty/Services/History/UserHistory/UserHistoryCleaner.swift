import Foundation

protocol UserHistoryCleaner: HistoryCleaner {}
