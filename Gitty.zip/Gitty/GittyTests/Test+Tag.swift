import Testing

extension Tag {
  @Tag static var history: Self
}
